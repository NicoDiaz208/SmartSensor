import { Component, OnInit, OnDestroy } from '@angular/core';
import * as $ from 'jquery';
import * as CanvasJS from './canvasjs.min';
import { GasService } from '../services/gas.service';
import { Gas } from '../models/gas.model';

@Component({
  selector: 'app-gas',
  templateUrl: './gas.component.html',
  styleUrls: ['./gas.component.css']
})
export class GasComponent implements OnInit, OnDestroy {

  setTimerId: number;
  temperatures: Array<Gas> = new Array<Gas>();
  constructor(private gasService: GasService) { }

  ngOnInit() {

    this.gasService.getGases().subscribe(data => {

      this.temperatures = data;
      let dataPoints = [];
      let chart = new CanvasJS.Chart("chartContainer", {
        animationEnabled: true,
        title: { text: "Gas Chart (update every 2 sec)" },
        data: [{
          type: "column",
          dataPoints: dataPoints,
        }]
      });
      this.temperatures.forEach((datapoint, idx) => { dataPoints.push({ x: idx, y: datapoint.CO2 }); });
      chart.render();
    })
    this.setTimerId = +setTimeout(() => this.ngOnInit(), 2000); // Update char with data from server
  }
  ngOnDestroy() {
    // diese methode wird imma aufgerufen wenn compo zerst wird also wenn du wechs
    clearTimeout(this.setTimerId);
  }
}
