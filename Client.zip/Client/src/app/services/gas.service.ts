import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Gas } from '../models/gas.model';

@Injectable({
  providedIn: 'root'
})
export class GasService {

  private url: string = "assets/data/test_JSON_Data_Gas.json"; // replace this url with server - später

  constructor(private http: HttpClient) { }
  getGases(): Observable<Gas[]> { return this.http.get<Gas[]>(this.url); }
}
