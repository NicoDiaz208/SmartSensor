import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Humidity } from '../models/humidity.model';

@Injectable({
  providedIn: 'root'
})
export class HumidityService {

  private url: string = "assets/data/test_JSON_Data_Humidity.json"; // replace this url with server - später

  constructor(private http: HttpClient) { }
  getHumidity(): Observable<Humidity[]> { return this.http.get<Humidity[]>(this.url); }
}
