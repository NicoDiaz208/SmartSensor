import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Temperature } from '../models/temperature.model';

@Injectable({
  providedIn: 'root'
})
export class TemperatureService {

  public url: string = "assets/data/test_JSON_Data_Temperature.json"; // replace this url with server - später

  constructor(private http: HttpClient) { }
  getTemperatures(): Observable<Temperature[]> { return this.http.get<Temperature[]>(this.url); }
}
