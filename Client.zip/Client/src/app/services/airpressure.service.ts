import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Airpressure } from '../models/airpressure.model'

@Injectable({
  providedIn: 'root'
})
export class AirpressureService {

  private url: string = "assets/data/test_JSON_Data_AirPressure.json"; // replace this url with server - später

  constructor(private http: HttpClient) { }
  getAirPressures(): Observable<Airpressure[]> { return this.http.get<Airpressure[]>(this.url); }
}
