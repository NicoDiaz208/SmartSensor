import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Airpressure } from '../models/airpressure.model'

@Injectable({
  providedIn: 'root'
})
export class AirpressureService {

  //private url: string = "assets/data/test_JSON_Data_AirPressure.json"; // replace this url with server - später
  private url: string = "http://90.146.160.166:9020";

  constructor(private http: HttpClient) { }
  getAirPressures(): Observable<Airpressure[]> { return this.http.get<Airpressure[]>(this.url); }

  getDatabyTopic(topic: string) {
    const params = new HttpParams().set('topic', topic);
    return this.http.get<any[]>(this.url + '/getTopic', { params });
  }
}
