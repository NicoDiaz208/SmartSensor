import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Lights } from '../models/lights.model';

@Injectable({
  providedIn: 'root'
})
export class LightsService {

  private url: string = "http://localhost:3000/lights"; // replace this url with server - später

  constructor(private http: HttpClient) { }
  addLights(lights: Lights) {
    this.http.post<Lights>(this.url, lights);
  }
}
