import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';;
import { HumidityComponent } from './humidity/humidity.component';
import { TemperatureComponent } from './temperature/temperature.component';
import { AirpressureComponent } from './airpressure/airpressure.component';
import { GasComponent } from './gas/gas.component';

const routes: Routes = [
  {
    path: 'airpressure',
    component: AirpressureComponent
  },
  {
    path: 'temperature',
    component: TemperatureComponent
  },
  {
    path: 'humidity',
    component: HumidityComponent
  },
  {
    path: 'gas',
    component: GasComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
