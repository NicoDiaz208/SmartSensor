export interface Gas {
    CO2: number // Carbon dioxide
}
