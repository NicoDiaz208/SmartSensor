export interface Temperature {
    degree: number
}
