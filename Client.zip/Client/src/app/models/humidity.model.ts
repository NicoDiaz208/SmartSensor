export interface Humidity {
    percentage: number // When the air is fully saturated with water vapor and cannot hold any more water vapor, the relative humidity is 100%. 
}
