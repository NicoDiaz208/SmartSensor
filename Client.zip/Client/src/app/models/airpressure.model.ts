export interface Airpressure {
    pressure: number
}
