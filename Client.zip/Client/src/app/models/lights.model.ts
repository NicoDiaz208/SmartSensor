export interface Lights {
    lightInLivingroom: boolean,
    lightInKitchen: boolean,
    lightInCellar: boolean,
    lightInGarage: boolean
}
