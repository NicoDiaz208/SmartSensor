import { Component, OnInit, OnDestroy } from '@angular/core';
import * as CanvasJS from './canvasjs.min';
import { AirpressureService } from '../services/airpressure.service';
import { Airpressure } from '../models/airpressure.model';

@Component({
  selector: 'app-airpressure',
  templateUrl: './airpressure.component.html',
  styleUrls: ['./airpressure.component.css']
})
export class AirpressureComponent implements OnInit, OnDestroy {

  pressures: Array<Airpressure> = new Array<Airpressure>();
  setTimerId: number;
  constructor(private airpressureService: AirpressureService) { }

  ngOnInit() { // oninit life cry metohde

    this.airpressureService.getDatabyTopic("Htl-Leonding2020NVS/SmartHome/Livingroom/AirPressure").subscribe(data => {
      //this.airpressureService.getAirPressures().subscribe(data => {

      this.pressures = data;

      //for (let i in data) {
      //  this.pressures.push({
      //    pressure: data.message
      //  })
      //}
      //console.log(this.pressures)

      //this.pressures = data;
      let dataPoints = [];
      let chart = new CanvasJS.Chart("chartContainer", {
        animationEnabled: true,
        title: { text: "Air Pressure Chart (update every 2 sec)" },
        data: [{
          type: "spline",
          dataPoints: dataPoints,
        }]
      });
      this.pressures.forEach((datapoint, idx) => { dataPoints.push({ x: idx, y: datapoint.pressure }); });
      chart.render();
    })// + wandelt ois in a zahl stack overflow 
    this.setTimerId = +setTimeout(() => this.ngOnInit(), 2000); // Update char with data from server
  }
  ngOnDestroy() {
    // diese methode wird imma aufgerufen wenn compo zerst wird also wenn du wechs
    clearTimeout(this.setTimerId);
  }
}
