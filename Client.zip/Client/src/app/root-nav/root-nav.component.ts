import { Component } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';
import { LightsService } from '../services/lights.service';
import { Lights } from '../models/lights.model';

@Component({
  selector: 'app-root-nav',
  templateUrl: './root-nav.component.html',
  styleUrls: ['./root-nav.component.css']
})
export class RootNavComponent {

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );

  constructor(private breakpointObserver: BreakpointObserver, private lightsService: LightsService) { }

  day_night: boolean = true;

  imgSun: String = "assets/images/sun.png"
  imgCloud1: String = "assets/images/cloud1.png"
  imgCloud2: String = "assets/images/cloud2.png"

  bgImage: String = "assets/images/smartHome.png";
  bgImageLight: String = "assets/images/light-bulb-icon.png";

  imgCar: String = "assets/images/car.png";
  imgBarrel: String = "assets/images/barrel.png";
  imgBarrel2: String = "assets/images/barrel2.png";
  imgGlass: String = "assets/images/glass.png";
  imgLivingroom: String = "assets/images/livingroom.png";
  imgKitchen: String = "assets/images/kitchen.png";

  imgMoon: String = "assets/images/moon.png";
  imgStar: String = "assets/images/star.png";
  imgStars: String = "assets/images/stars.png";

  lights: Lights = {
    lightInLivingroom: false,
    lightInKitchen: false,
    lightInCellar: false,
    lightInGarage: false
  }

  sendLightsToTheServer() {
    this.lightsService.addLights(this.lights); // .subscribe(lights => this.lights.push(lights))
  }

  colorA = 'skyblue'
  colorB = '#1f263b' // night color

  //airPressureLink = '<app-humidity></app-humidity>'
  //airPressureLink = "<a routerLink]=['humidity']></a>"
  showAirPressure() {
    //window.open('http://localhost:4200/humidity', 'Air Pressure', 'width=1200,height=400,left=200,top=200'); var window = window.open(url, windowName, [windowFeatures]);
  }
}
