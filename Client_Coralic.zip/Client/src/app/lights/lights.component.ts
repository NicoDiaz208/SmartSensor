import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lights',
  templateUrl: './lights.component.html',
  styleUrls: ['./lights.component.css']
})
export class LightsComponent implements OnInit {

  turnLight : boolean = false;
  bgImage : String = "assets/images/light-bulb-icon.png";

  constructor() { }
  ngOnInit(): void { }
}
