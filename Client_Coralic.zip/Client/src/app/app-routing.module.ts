import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { HumidityComponent } from './humidity/humidity.component';
import { LightsComponent } from './lights/lights.component';
import { TemperatureComponent } from './temperature/temperature.component';

const routes: Routes = [
  {
    path:'home',
    component: HomeComponent
  },
  {
    path:'humidity',
    component: HumidityComponent
  },
  {
    path:'lights',
    component: LightsComponent
  },
  {
    path:'temperature',
    component: TemperatureComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
